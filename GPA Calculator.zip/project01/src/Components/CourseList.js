import React from 'react';

const CourseList = ({ courses, calculateGPA }) => {
  return (
    <div>
      <h3>Current GPA: {calculateGPA()}</h3>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Course</th>
            <th>Credits</th>
            <th>Grade</th>
          </tr>
        </thead>
        <tbody>
          {courses.map((course, index) => (
            <tr key={index}>
              <td>{course.courseName}</td>
              <td>{course.creditHours}</td>
              <td>{course.grade}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CourseList;
