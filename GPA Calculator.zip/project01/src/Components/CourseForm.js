import React from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';

const CourseForm = ({
  studentName,
  courseName,
  creditHours,
  grade,
  onAddCourse,
  onAddStudent,
  setStudentName,
  setCourseName,
  setCreditHours,
  setGrade,
  currentGPA,
}) => {
  const addCourse = () => {
    onAddCourse();
  };

  const addStudent = () => {
    onAddStudent();
  };

  return (
    <Container>
      <h3>Enter Student Name</h3>
      <Form.Group>
        <Form.Control
          type="text"
          placeholder="Student Name"
          value={studentName}
          onChange={(e) => setStudentName(e.target.value)}
        />
      </Form.Group>
      <h3>Enter Course Details</h3>
      <Form.Group>
        <Form.Control
          type="text"
          placeholder="Course Name"
          value={courseName}
          onChange={(e) => setCourseName(e.target.value)}
        />
        <Form.Control
          type="number"
          placeholder="Credit Hours"
          value={creditHours}
          onChange={(e) => setCreditHours(Number(e.target.value))}
        />
        <Form.Control
          as="select"
          value={grade}
          onChange={(e) => setGrade(e.target.value)}
        >
          <option value="A+">A+</option>
          <option value="A">A</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option value="B">B</option>
          <option value="B-">B-</option>
          <option value="C+">C+</option>
          <option value="C">C</option>
          <option value="C-">C-</option>
          <option value="D+">D+</option>
          <option value="D">D</option>
          <option value="D-">D-</option>
        </Form.Control>
      </Form.Group>
      <Row>
        <Col>
          <Button variant="primary" onClick={addCourse}>
            Add Course
          </Button>
        </Col>
        <Col>
          <Button variant="success" onClick={addStudent}>
            Add Student
          </Button>
        </Col>
      </Row>
      <div className="mt-3">
        
        <div style={{ backgroundColor: 'azure', padding: '5px', borderRadius: '5px' }}>
          {currentGPA} 
        </div>
      </div>
    </Container>
  );
};

export default CourseForm;
