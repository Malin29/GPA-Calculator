import React from 'react';
import { Button } from 'react-bootstrap';

const StudentDetails = ({ students, onRemoveStudent }) => {
  return (
    <div>
      <h2>Student Details</h2>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Student Name</th>
            <th>GPA</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students
            .sort((a, b) => b.gpa - a.gpa)
            .map((student, index) => (
              <tr key={index}>
                <td>{student.studentName}</td>
                <td>{student.gpa}</td>
                <td>
                  <Button
                    variant="danger"
                    onClick={() => onRemoveStudent(index)}
                  >
                    Remove
                  </Button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
};

export default StudentDetails;
