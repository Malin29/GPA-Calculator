import React, { useState } from 'react';
import CourseForm from './CourseForm';
import CourseList from './CourseList';

const gradePoints = {
  'A+': 4.0,
  'A': 4.0,
  'A-': 3.7,
  'B+': 3.3,
  'B': 3.0,
  'B-': 2.7,
  'C+': 2.3,
  'C': 2.0,
  'C-': 1.7,
  'D+': 1.3,
  'D': 1.0,
  'D-': 0.7,
};

const GPACalculator = ({ onAddStudent }) => {
  const [studentName, setStudentName] = useState('');
  const [courses, setCourses] = useState([]);
  const [courseName, setCourseName] = useState('');
  const [creditHours, setCreditHours] = useState(0);
  const [grade, setGrade] = useState('A+');

  const addCourse = () => {
    if (courses.length < 5) {
      const newCourse = {
        courseName,
        creditHours,
        grade,
      };
      setCourses([...courses, newCourse]);
      setCourseName('');
      setCreditHours(0);
      setGrade('A+');
    } else {
      alert('You can only add up to 5 courses per student.');
    }
  };

  const calculateGPA = () => {
    let totalGradePoints = 0;
    let totalCreditHours = 0;

    courses.forEach((course) => {
      totalGradePoints += gradePoints[course.grade] * course.creditHours;
      totalCreditHours += course.creditHours;
    });

    return totalCreditHours === 0 ? 0 : (totalGradePoints / totalCreditHours).toFixed(2);
  };

  const addStudent = () => {
    if (studentName && courses.length > 0) {
      const newStudent = {
        studentName,
        courses,
        gpa: calculateGPA(),
      };
      onAddStudent(newStudent);
      setStudentName('');
      setCourses([]);
    } else {
      alert('Please enter valid student details and at least one course.');
    }
  };

  return (
    <div>
      <h2>GPA Calculator</h2>
      <CourseForm
        studentName={studentName}
        courseName={courseName}
        creditHours={creditHours}
        grade={grade}
        courses={courses}
        onAddCourse={addCourse}
        onAddStudent={addStudent}
        setStudentName={setStudentName}
        setCourseName={setCourseName}
        setCreditHours={setCreditHours}
        setGrade={setGrade}
      />
      <CourseList courses={courses} calculateGPA={calculateGPA} />
    </div>
  );
};

export default GPACalculator;