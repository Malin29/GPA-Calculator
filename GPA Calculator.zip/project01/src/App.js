import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Nav, Navbar } from 'react-bootstrap';
import './App.css';
import GPACalculator from './Components/GPACalculator';
import StudentDetails from './Components/StudentDetails';

function App() {
  const [activeTab, setActiveTab] = useState('gpaCalculator');
  const [students, setStudents] = useState([]);

  const addStudent = (student) => {
    setStudents([...students, student]);
  };

  const removeStudent = (index) => {
    const updatedStudents = [...students];
    updatedStudents.splice(index, 1);
    setStudents(updatedStudents);
  };

  return (
    <Container className="mt-4">
      <Navbar bg="light" expand="lg">
        <Navbar.Brand>GPA App</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <Nav.Link
              active={activeTab === 'gpaCalculator'}
              onClick={() => setActiveTab('gpaCalculator')}
            >
              GPA Calculator
            </Nav.Link>
            <Nav.Link
              active={activeTab === 'studentDetails'}
              onClick={() => setActiveTab('studentDetails')}
            >
              Student Details
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
      {activeTab === 'gpaCalculator' && (
        <GPACalculator onAddStudent={addStudent} />
      )}
      {activeTab === 'studentDetails' && (
        <StudentDetails students={students} onRemoveStudent={removeStudent} />
      )}
    </Container>
  );
}

export default App;